
<div class="row">
    <div class="col-md-8">
        <div class="form-group  <?php echo e($errors->has('title') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('title', 'Title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

            <?php if($errors->has('title')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('title')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group  <?php echo e($errors->has('alias') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('alias', 'Алиас:'); ?>

            <?php echo Form::text('alias', null, ['class'=>'form-control']); ?>

            <?php if($errors->has('alias')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('alias')); ?></small>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-8">
        <div class="form-group  <?php echo e($errors->has('intro_text') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('intro_text', 'Вводный текст:'); ?>

            <?php echo Form::textarea('intro_text', null, ['class'=>'form-control', 'rows'=>'3', ]); ?>

            <?php if($errors->has('intro_text')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('intro_text')); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group  <?php echo e($errors->has('full_text') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('full_text', 'Полный текст:'); ?>


            <tinymce name="full_text">
                <?php echo e($post->full_text); ?>

            </tinymce>
            
            <?php if($errors->has('full_text')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('full_text')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-4">



        <div class="form-group  <?php echo e($errors->has('enabled') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('published', 'Опубликовано:'); ?>

            <?php echo Form::select('published', array('0' => 'Нет', '1' => 'Да'), null, ['class'=>'form-control select']); ?>

        </div>

        
            
            
        

        <div class="form-group  <?php echo e($errors->has('enabled') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('cat_id', 'Категории:'); ?>

            <?php echo Form::select('cat_id', $categories, null, ['class'=>'form-control select2']); ?>

        </div>

        <?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <img src="/<?php echo e($photo->path . '/' . $photo->thumbnail_filename); ?>" class="img-responsive" alt="<?php echo e($photo->original_name); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        
            
            
        

        
            
            
        
    </div>
</div>


<div class="form-group">
    <?php echo Form::submit( $submitButtonText, ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn btn-secondary">Назад</a>
</div>


<?php $__env->startSection('footer'); ?>

    <script type="text/javascript" src="<?php echo asset('build/media/ckeditor/ckeditor.js'); ?>"></script>

    <script>
        CKEDITOR.replace('body',{
            filebrowserBrowseUrl : '/elfinder/ckeditor'
        });

    </script>

<?php $__env->stopSection(); ?>