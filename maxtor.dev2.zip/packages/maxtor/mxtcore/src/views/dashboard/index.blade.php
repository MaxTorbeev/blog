@extends('mxtcore::layouts.dashboard')

@section('content')

@endsection