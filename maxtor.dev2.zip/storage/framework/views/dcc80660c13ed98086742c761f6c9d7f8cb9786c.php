<?php $__env->startSection('content'); ?>
    <h2>Создание новой категории</h2>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <?php echo Form::model($category = new \MaxTor\Blog\Models\Category(), ['url' => route('categories.store'), 'files' => true, 'method' => 'POST']); ?>

    <?php echo $__env->make('blog::dashboard.categories.form', ['submitButtonText' => 'Добавить категорию'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>