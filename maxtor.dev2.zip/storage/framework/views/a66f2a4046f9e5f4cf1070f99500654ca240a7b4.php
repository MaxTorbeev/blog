<?php $__env->startSection('meta'); ?>
    <meta name="keywords" content="<?php echo e($post->metakey); ?>">
    <meta name="description" content="<?php echo e($post->metadesc); ?>">
    <meta property="og:title" content="<?php echo e($post->title); ?>">
    <meta property="og:description" content="<?php echo e($post->intro_text); ?>">
    <meta property="og:site_name" content="maxtor.name">
    <meta property="og:url" content="<?php echo e(route('post.show', ['alias' => $post->alias])); ?>">
    <meta property="og:type" content="article">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('update', $post)): ?>
        <a href="#">Редактирование </a>
    <?php endif; ?>

    <article class="post">
        <div class="row">

            <div class="col col-3">

                <div class="swiper-container hBlogImagesSlider">
                    <div class="swiper-wrapper">
                    <?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="swiper-slide">
                            <img src="/<?php echo e($photo->path . '/' . $photo->thumbnail_filename); ?>" class="img-fluid" alt="<?php echo e($photo->original_name); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination"></div>
                    <!-- Add Arrows -->
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
                
                    
                
            </div>

            <div class="col col-9">

                <h1 class="post_title"><?php echo e($post->title); ?></h1>

                <ul class="post_info">
                    <li class="post_info_item">
                        <span>Опубликовано: <?php echo e($post->published_at); ?></span>
                    </li>
                    <li class="post_info_item">
                        <span>Пользователем: <?php echo e($post->user); ?></span>
                    </li>
                </ul>

                <div class="post_introText mtn lead">
                    <?php echo e($post->intro_text); ?>

                    
                </div>

                <div class="post_fullText">
                    <?php echo $post->full_text; ?>

                </div>
            </div>
        </div>


        <div class="row">
            <div class="col col-9">

            </div>
        </div>
    </article>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>