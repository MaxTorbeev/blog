@extends('mxtcore::layouts.app')

@section('content')
    <h1 class="text-center">Страница не найдена!</h1>
@endsection