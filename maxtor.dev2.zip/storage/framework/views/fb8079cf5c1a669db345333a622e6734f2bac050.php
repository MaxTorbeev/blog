<?php if(session()->has('flash_message')): ?>
    <script>
        swal({
            title: "<?php echo e(session('flash_message.title')); ?>",
            text:  "<?php echo e(session('flash_message.message')); ?>",
            type:  "<?php echo e(session('flash_message.level')); ?>",
            confirmButton: false,
            timer: 1000
        });
    </script>
<?php endif; ?>

<?php if(session()->has('flash_message_overlay')): ?>
    <script>
        swal({
            title: "<?php echo e(session('flash_message_overlay.title')); ?>",
            text:  "<?php echo e(session('flash_message_overlay.message')); ?>",
            type:  "<?php echo e(session('flash_message_overlay.level')); ?>",
            confirmButtonText: 'Ok'
        });
    </script>
<?php endif; ?>