
<nav class="navbar navbar-toggleable-md navbar-light bg-faded mb-1">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li class="nav-item active">
                <a href="<?php echo e($item['url']); ?>" class="btn btn-primary btn btn-sm mr-1"><?php echo e($item['title']); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
</nav>