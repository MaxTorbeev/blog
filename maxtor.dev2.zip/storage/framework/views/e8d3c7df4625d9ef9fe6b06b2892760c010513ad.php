<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('mxtcore::dashboard.partials.components.toolbar', [
        'menu' => [
                    [
                        'url'      => url( '/admin/' . $page->alias . '/create'),
                        'title'    => 'Добавить материал'
                    ],
            ]
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <table class="table table-sm ">
        <thead class="thead-inverse">
        <tr>
            <th>Заголовок материала</th>
            <th>Категория</th>
            <th>Автор</th>
            <th>Просмотры</th>
            <th>id</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><a href="<?php echo e(url( '/admin/' . $page->alias . '/edit', [$post->id])); ?>"><?php echo e($post->title); ?></a></td>
                <td><?php echo e($post->category->title); ?></td>
                <td><?php echo e($post->author->name); ?></td>
                <td><?php echo e($post->hits); ?></td>
                <th scope="row"><?php echo e($post->id); ?></th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>