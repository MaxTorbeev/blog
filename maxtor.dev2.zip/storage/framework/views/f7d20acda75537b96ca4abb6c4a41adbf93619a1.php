<?php $__env->startSection('content'); ?>

    <h1><?php echo e($e->getMessage()); ?></h1>

    <div>file: <?php echo e($e->getFile()); ?></div>
    <div>code: <?php echo e($e->getCode()); ?></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>