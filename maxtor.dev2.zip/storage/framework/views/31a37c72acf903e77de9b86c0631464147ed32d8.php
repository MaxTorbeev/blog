
<div class="row">
    <div class="col-md-8">
        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <?php echo Form::label('title', 'Title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <?php echo Form::label('alias', 'Алиас:'); ?>

            <?php echo Form::text('alias', null, ['class'=>'form-control']); ?>

        </div>
    </div>
</div>


<div class="row">
    <div class="col-sm-8">
        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <?php echo Form::label('intro_text', 'Вводный текст:'); ?>

            <?php echo Form::textarea('intro_text', null, ['class'=>'form-control', 'rows'=>'3', ]); ?>

        </div>
        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <?php echo Form::label('full_text', 'Полный текст:'); ?>

            <?php echo Form::textarea('full_text', null, ['class'=>'form-control', 'id'=>'editor']); ?>

        </div>
    </div>
    <div class="col-sm-4">

        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <?php echo Form::label('published', 'Опубликовано:'); ?>

            <?php echo Form::select('published', array('0' => 'Нет', '1' => 'Да'), null, ['class'=>'form-control select']); ?>

        </div>

        
            
            
        

        
            
            
        

        
            
            
        

        
            
            
        

    </div>
</div>


<div class="form-group">
    <?php echo Form::submit( $submitButtonText, ['class' => 'btn btn-primary form-control']); ?>

</div>


<?php $__env->startSection('footer'); ?>

    <script type="text/javascript" src="<?php echo asset('build/media/ckeditor/ckeditor.js'); ?>"></script>

    <script>
        CKEDITOR.replace('body',{
            filebrowserBrowseUrl : '/elfinder/ckeditor'
        });

    </script>

<?php $__env->stopSection(); ?>