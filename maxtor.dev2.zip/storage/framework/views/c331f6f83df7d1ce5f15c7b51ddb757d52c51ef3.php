<div class="form-group">
    <?php echo Form::label('name', 'Название тега:'); ?>

    <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('alias', 'Алиас:'); ?>

    <?php echo Form::text('alias', null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <tinymce name="description">
        <?php echo e($tag->description); ?>

    </tinymce>
</div>

<div class="form-group">
    <?php echo Form::submit( $submitButtonText, ['class' => 'btn btn-sm btn-primary']); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-secondary">Назад</a>
</div>

