<div class="row">
    <div class="col-md-8">
        <div class="form-group  <?php echo e($errors->has('title') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('title', 'Title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

            <?php if($errors->has('title')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('title')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group  <?php echo e($errors->has('alias') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('alias', 'Алиас:'); ?>

            <?php echo Form::text('alias', null, ['class'=>'form-control']); ?>

            <?php if($errors->has('alias')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('alias')); ?></small>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-8">
        <div class="form-group  <?php echo e($errors->has('intro_text') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('intro_text', 'Вводный текст:'); ?>

            <?php echo Form::textarea('intro_text', null, ['class'=>'form-control', 'rows'=>'3', ]); ?>

            <?php if($errors->has('intro_text')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('intro_text')); ?></small>
            <?php endif; ?>
        </div>
        <div class="form-group  <?php echo e($errors->has('full_text') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('full_text', 'Полный текст:'); ?>


            <tinymce name="full_text"> <?php echo e($post->full_text); ?> </tinymce>
            <?php if($errors->has('full_text')): ?>
                <small class="form-control-feedback"><?php echo e($errors->first('full_text')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-4">

        <div class="form-group  <?php echo e($errors->has('enabled') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('preview_photo_id', 'Изображение вводного текста:'); ?>


            <?php echo Form::select('preview_photo_id', $photos, null, ['class'=>'form-control selectPreviewPhoto', 'data-post-id' => $post->id]); ?>

        </div>

        <div class="form-group  <?php echo e($errors->has('enabled') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('published', 'Опубликовано:'); ?>

            <?php echo Form::select('published', array('0' => 'Нет', '1' => 'Да'), null, ['class'=>'form-control select']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('published_at', 'Publish on:'); ?>

            <?php echo Form::input('data', 'published_at', $post->published_at, ['class'=>'form-control' ]); ?>

        </div>

        <div class="form-group  <?php echo e($errors->has('enabled') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('cat_id', 'Категории:'); ?>

            <?php echo Form::select('cat_id', $categories, null, ['class'=>'form-control select2']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('tag_list', 'Tags:'); ?>

            <?php echo Form::select('tag_list[]', $tags, $post->tags->pluck('id')->all(), ['class'=>'form-control select2' , 'multiple']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('metadesc', 'meta-description:'); ?>

            <?php echo Form::input('text', 'metadesc', $post->metadesc, ['class'=>'form-control' ]); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('metakey', 'meta-keywords:'); ?>

            <?php echo Form::input('text', 'metakey', $post->metakey, ['class'=>'form-control' ]); ?>

        </div>
    </div>
</div>

<div class="form-group">
    <?php echo Form::submit( $submitButtonText, ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn btn-secondary">Назад</a>
</div>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>