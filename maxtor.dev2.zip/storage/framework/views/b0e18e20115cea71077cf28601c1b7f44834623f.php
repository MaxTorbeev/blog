<?php $__env->startSection('content'); ?>
    <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('update', $post)): ?>
        <a href="#">Редактирование </a>
    <?php endif; ?>
    <div class="blog-content">
        <div class="entry-header">
            <h2 class="entry-title"><?php echo e($post->title); ?></h2>
        </div>

        <div class="entry-content">
            <?php echo e($post->full_text); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>