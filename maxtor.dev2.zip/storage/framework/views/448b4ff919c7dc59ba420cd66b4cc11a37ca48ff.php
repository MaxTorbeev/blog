<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    You are logged in!
                </div>
                
                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('edit_forum')): ?>
                    <h1>Can edit_forum</h1>
                <?php endif; ?>

                <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('manage_money')): ?>
                <h1>Can manage_money</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mxtcore::layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>