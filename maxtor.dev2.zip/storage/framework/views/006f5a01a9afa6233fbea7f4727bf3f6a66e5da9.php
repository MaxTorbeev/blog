<?php $__env->startSection('content'); ?>
    <h2>Редактирование материала</h2>

    <?php echo Form::model($post, ['url' =>  route('post.update', [$post->id]), 'files' => true, 'method' => 'PATCH']); ?>

        <?php echo $__env->make('blog::dashboard.posts.form', [
        'submitButtonText' => 'Редактировать материал',
        'deletePost' => 'true'
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

    <h3>Добавить изображения</h3>
    <?php echo Form::model(
           $post,
           [
               'action' => ['\MaxTor\Blog\Controllers\PostsController@addPhoto', $post->alias],
               'id' => 'addPhotoForm',
               'class' => 'dropzone',
               'files' => true
           ]); ?>

    <?php echo Form::close(); ?>


    <form method="POST" action="<?php echo e(route('post.destroy', [$post->id])); ?>" v-ajax>
        <?php echo e(method_field('DELETE')); ?>

        <?php echo e(csrf_field()); ?>

        <button type="submit">Delete Post</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>