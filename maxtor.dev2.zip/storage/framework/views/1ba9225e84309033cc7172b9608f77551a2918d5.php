
<div class="row">
    <div class="col col-md-8">
        <div class="form-group row <?php echo e($errors->has('name') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('name', 'Имя расширения:', ['class' => 'col col-xs-4 col-form-label']); ?>

            <div class="col col-xs-8">
                <?php echo Form::text('name', $extension->name, ['class'=>'form-control']); ?>

                <?php if($errors->has('name')): ?>
                    <small class="form-control-feedback"><?php echo e($errors->first('name')); ?></small>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('controller_path') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('controller_path', 'Используемый контроллер:', ['class' => 'col col-xs-4 col-form-label']); ?>

            <div class="col col-xs-8">
                <?php echo Form::text('controller_path', $extension->controller_path, ['class'=>'form-control']); ?>

                <?php if($errors->has('controller_path')): ?>
                    <small class="form-control-feedback"><?php echo e($errors->first('controller_path')); ?></small>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row <?php echo e($errors->has('enabled') ? 'has-danger' : ''); ?>">
            <?php echo Form::label('enable', 'Включить расширение? ', ['class' => 'col col-xs-4 col-form-label']); ?>

            <div class="col col-xs-8">
                <?php echo Form::select('enabled', ['0' => 'Нет', '1' => 'Да'], 1, ['class'=>'form-control select']); ?>

                <?php if($errors->has('enabled')): ?>
                    <small class="form-control-feedback"><?php echo e($errors->first('enabled')); ?></small>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <?php echo Form::submit( $submitButtonText, ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
</div>


