<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('mxtcore::dashboard.partials.components.toolbar', [
        'menu' => [
                    [
                        'url'      => route('dashboard.components', ['alias' => $page->alias, 'method' => 'create']),
                        'title'    => 'Добавить расширение'
                    ],
            ]
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__currentLoopData = $extensions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extension): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo Form::model($extension, ['method' => 'PATCH',  'url' => route('extensions.update', ['id' => $extension->id]), 'class' => 'form-table input-group']); ?>

            <input type="hidden" name="_method" value="PATCH">
            <div class="tr">
                <span class="input-group-addon input-group-addon-sm">id:<?php echo e($extension->id); ?>:</span>
                <div class="td">
                    <?php echo Form::input('text', 'name', $extension->name, ['class'=>'form-control form-control-sm' ]); ?>

                </div>

                <span class="input-group-addon input-group-addon-sm">controller path:</span>
                <div class="td">
                    <?php echo Form::input('controller_path', 'controller_path', $extension->controller_path, ['class'=>'form-control form-control-sm' ]); ?>

                </div>

                <div class="td">
                    <?php if( $extension->enabled == 1): ?>
                    <button type="button" class="btn btn-sm btn-warning btn-block">Отключить</button>
                    <?php else: ?>
                    <button type="button" class="btn btn-sm btn-success btn-block">Включить</button>
                    <?php endif; ?>
                </div>

                <div class="td">
                    <?php echo Form::submit( 'Изменить', ['class' => 'btn btn-sm btn-primary btn-block']); ?>

                </div>
            </div>
        <?php echo Form::close(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>