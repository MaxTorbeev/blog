<?php $__env->startSection('content'); ?>
    <?php echo Form::model($menu, ['url' => route('menu.store')]); ?>

    <?php echo $__env->make('mxtcore::dashboard.menu.menu-items.form', ['submitButtonText' => 'Добавить новый пункт меню' ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>