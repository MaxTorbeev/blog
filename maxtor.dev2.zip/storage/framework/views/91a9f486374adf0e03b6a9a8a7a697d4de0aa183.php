<?php $__env->startSection('content'); ?>
    <h1>Create new post</h1>
    <hr>

    
        
            
                
                    
                
            
        
    


    <?php echo Form::model($post = new \MaxTor\Blog\Models\Post(), ['url' => 'posts', 'files' => true]); ?>

    <?php echo $__env->make('blog::form', [
        'submitButtonText' => 'Добавить новый материал'
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>