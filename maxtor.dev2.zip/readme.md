# MaxTor blog

Мой личный блог, основанный на [Laravel framework](http://laravel.com), который использует мною разработанные пакеты, которые будут добавлены composer репозитории

## Установка и использование

* php artisan migrate
* php artisan db:seed
* php artisan blog:install


## Лицензия

MaxTor Blog веб-приложение с открытым исходным кодом, распортроняется по лицензии [MIT](http://opensource.org/licenses/MIT).
