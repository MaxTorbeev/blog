<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('mxtcore::dashboard.partials.components.toolbar', [
        'menu' => [
                    [
                        'url'      => url( '/admin/' . $page->alias . '/create'),
                        'title'    => 'Добавить категорию'
                    ],
            ]
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <table class="table table-sm ">
        <thead class="thead-inverse">
        <tr>
            <th>Заголовок категории</th>
            <th>Материалы</th>
            <th>Автор</th>
            <th>Просмотры</th>
            <th>id</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><a href="<?php echo e(url( '/admin/' . $page->alias . '/edit', [$category->id])); ?>"><?php echo e($category->title); ?></a></td>
            <td><?php echo e(count($category->posts)); ?></td>
            <td><?php echo e($category->author->name); ?></td>
            <td><?php echo e($category->hits); ?></td>
            <th scope="row"><?php echo e($category->id); ?></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>