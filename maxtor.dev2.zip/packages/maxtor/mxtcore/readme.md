# MXTCore package

Ядро приложения основанное на Laravel framework 5.3+
