
<div class="row">
    <div class="col-md-8">
        <div class="form-group">
            <?php echo Form::label('title', 'Title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('alias', 'Алиас:'); ?>

            <?php echo Form::text('alias', null, ['class'=>'form-control']); ?>

        </div>
    </div>
</div>


<div class="row">
    <div class="col-sm-8">
        <div class="form-group">
            <?php echo Form::label('description', 'Описание:'); ?>

            <?php echo Form::textarea('description', null, ['class'=>'form-control', 'id'=>'editor']); ?>

        </div>
    </div>
    <div class="col-sm-4">

        <div class="form-group">
            <?php echo Form::label('state', 'Опубликовано:'); ?>

            <?php echo Form::select('state', array('0' => 'Нет', '1' => 'Да'), null, ['class'=>'form-control select']); ?>

        </div>

        
        
        
        

        <div class="form-group">
            <?php echo Form::label('parent_id', 'Родительская категория:'); ?>

            <?php echo Form::select('parent_id', $categoryList, null, ['class'=>'form-control select2']); ?>

        </div>

        
        
        
        

        
        
        
        

    </div>
</div>


<div class="form-group">
    <?php echo Form::submit( $submitButtonText, ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn btn-secondary">Назад</a>
</div>


<?php $__env->startSection('footer'); ?>

    <script type="text/javascript" src="<?php echo asset('build/media/ckeditor/ckeditor.js'); ?>"></script>

    <script>
        CKEDITOR.replace('body',{
            filebrowserBrowseUrl : '/elfinder/ckeditor'
        });

    </script>

<?php $__env->stopSection(); ?>