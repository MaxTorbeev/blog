<?php  $menuType = ''  ?>



<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('mxtcore::dashboard.partials.components.toolbar', [
        'menu' => [
                    [
                        'url'      => route('dashboard.components', ['alias' => $page->alias, 'method' => 'createmenuitem']),
                        'title'    => 'Добавить пункт меню'
                    ],
                    [
                        'url'      => route('dashboard.components', ['alias' => $page->alias, 'method' => 'createMenuType']),
                        'title'    => 'Добавить новый тип меню'
                    ],
            ]
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php if($menuType != $item->menuType->title): ?>
        <h4><?php echo e($item->menuType->title); ?></h4>
        <hr>
        <?php endif; ?>
        <?php echo Form::model($item, ['metod' => 'PATCH',  'url' => route('menu.update', ['id' => $item->id]), 'class' => 'form-table input-group']); ?>

        <input type="hidden" name="_method" value="PATCH">
        <div class="tr">
            <span class="input-group-addon input-group-addon-sm"><?php echo e($item->id); ?>:</span>
            <div class="td">
                <?php echo Form::input('text', 'title', $item->title, ['class'=>'form-control form-control-sm' ]); ?>

            </div>

            <span class="input-group-addon input-group-addon-sm">alias:</span>
            <div class="td">
                <?php echo Form::input('text', 'alias', $item->alias, ['class'=>'form-control form-control-sm']); ?>

            </div>

            <span class="input-group-addon input-group-addon-sm">type:</span>
            <div class="td">
                <?php echo Form::select('menu_type_id', $menuTypes, $item->meny_type_id, ['class'=>'form-control form-control form-control-sm']); ?>

            </div>

            <span class="input-group-addon input-group-addon-sm">parent:</span>
            <div class="td">
                <?php echo Form::select('parent_id', $parentMenuItem, null, ['class'=>'form-control form-control form-control-sm']); ?>

            </div>

            <div class="td">
                <?php echo Form::select('extensions_id', $extensions, $item->extensions_id, ['class'=>'form-control form-control form-control-sm']); ?>

            </div>

            <div class="td">
                <?php if( $item->published == 1): ?>
                    <button type="button" class="btn btn-sm btn-warning btn-block">Откл</button>
                <?php else: ?>
                    <button type="button" class="btn btn-sm btn-success btn-block">Вклю</button>
                <?php endif; ?>
            </div>

            <div class="td">
                <?php echo Form::submit( 'Изменить', ['class' => 'btn btn-sm btn-primary btn-block']); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>


        <?php  $menuType = $item->menuType->title  ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>