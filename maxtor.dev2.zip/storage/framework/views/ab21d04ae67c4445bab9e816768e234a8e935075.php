<?php $__env->startSection('content'); ?>
    <h1>Страница не найдена</h1>
    <?php if(\Illuminate\Support\Facades\Auth::user()): ?>
        <?php echo e($e->getCode()); ?>

        <?php echo e($e->getMessage()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>