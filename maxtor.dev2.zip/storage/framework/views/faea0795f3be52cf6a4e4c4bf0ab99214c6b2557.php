<?php $__env->startSection('content'); ?>
    <div class="card-columns">

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="card">
            <?php if($post->previewImage): ?>
                <a href="<?php echo e(route('post.show',  ['alias' => $post->alias])); ?>">
                    <img src="/<?php echo e($post->previewImage->getThumbnail()); ?>"  class="card-img-top img-fluid" alt="<?php echo e($post->title); ?>">
                </a>
            <?php endif; ?>
            <div class="card-block">
                <h4 class="card-title">
                    <a href="<?php echo e(route('post.show',  ['alias' => $post->alias])); ?>"><?php echo e($post->title); ?></a>
                </h4>
                <p class="card-text"><?php echo e($post->intro_text); ?></p>
                <?php if($post->published_at): ?>
                    <p class="card-text"><small class="text-muted"><?php echo e($post->published_at); ?></small></p>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>