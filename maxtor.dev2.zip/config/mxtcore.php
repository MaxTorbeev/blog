<?php
/**
 * Configure file for MXTCore
 */
return [
    'baseUrl'       => 'maxtor.dev2',
    'title'         => 'Личный сайт Максима Торбеев',
    'keywords'      => 'Блог, web дизайн',
    'description'   => 'Личный сайт Максима Торбеева',
    'generator'     => 'MXTCore'
];
