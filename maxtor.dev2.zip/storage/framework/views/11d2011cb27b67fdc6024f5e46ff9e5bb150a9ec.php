<?php $__env->startSection('content'); ?>
    <style>
        .completed{
            text-decoration: underline;
        }
    </style>

    <alert type="error">
        <strong>Error</strong> Your account has not been updated.
    </alert>

    <menu-items></menu-items>


    <form-table
            id="1"
            action="/admin/manage-menus/apiItem"
    >

    </form-table>

    
        
        
        
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>