<!DOCTYPE html>
<html lang="ru">
<head>
    <base href="<?php echo e(config('mxtcore.baseUrl')); ?>" target="_top">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="keywords" content="<?php echo e(config('mxtcore.keywords')); ?>">
    <meta name="description" content="<?php echo e(config('mxtcore.description')); ?>">
    <meta name="generator" content="<?php echo e(config('mxtcore.generator')); ?>">

    <title><?php echo e(config('mxtcore.title', 'MaxTor blog')); ?></title>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([ 'csrfToken' => csrf_token(), ]); ?>
    </script>
</head>
<body>
afsdfsdfsd
<nav class="navbar navbar-light bg-faded">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">MaxTor.name v 2</a>
    <ul class="nav navbar-nav">
        <li class="nav-item active"> <a class="nav-link" href="#">Главная <span class="sr-only">(current)</span></a></li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('post.index')); ?>">Блог</a>
        </li>
        <li class="nav-item"><a class="nav-link" href="#">Портфолио</a></li>
        <?php if(Auth::guest()): ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/register')); ?>">Register</a></li>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                    <?php echo e(Auth::user()->name); ?>

                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a href="<?php echo e(url('/logout')); ?>" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Выход</a>
                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
                </div>
            </li>
        <?php endif; ?>
    </ul>
</nav>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Scripts -->
<script src="/js/app.js"></script>

<?php echo $__env->yieldContent('scripts.footer'); ?>

<?php echo $__env->make('partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
