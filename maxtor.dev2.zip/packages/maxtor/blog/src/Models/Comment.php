<?php

namespace MaxTor\Blog\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    //
}
