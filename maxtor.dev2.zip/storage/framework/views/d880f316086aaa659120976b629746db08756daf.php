<li>
    <a href="<?php echo e(route('dashboard.components'). '/' . $item->alias); ?>"><?php echo e($item->title); ?></a>
    <?php if(count($item->children) > 0): ?>
        <ul>
            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php echo $__env->make('mxtcore::dashboard.partials.sidebar.menu', $item, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    <?php endif; ?>
</li>