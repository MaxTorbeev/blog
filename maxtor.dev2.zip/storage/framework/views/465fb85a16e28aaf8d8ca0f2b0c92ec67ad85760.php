<?php $__env->startSection('content'); ?>
    <h2>Редактирование категории</h2>

    <?php echo Form::model($category, ['url' => route('categories.update', [$category->id]), 'files' => true, 'method' => 'PATCH']); ?>

    <?php echo $__env->make('blog::dashboard.categories.form', ['submitButtonText' => 'Редактировать категорию'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>