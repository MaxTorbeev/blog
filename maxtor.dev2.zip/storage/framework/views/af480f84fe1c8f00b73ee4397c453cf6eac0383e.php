<?php $__env->startSection('content'); ?>
    <?php echo Form::model($tag = new \MaxTor\Blog\Models\Tag(), ['url' => 'tags', 'files' => true]); ?>

    <?php echo $__env->make('blog::dashboard.tags.form', ['submitButtonText' => 'Добавить новый тег' ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>