<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col col-5">
            <tags-form></tags-form>
            
                
            
        </div>
        <div class="col col-7">
            <table class="table table-sm ">
                <thead class="thead-inverse">
                <tr>
                    <th>Тег</th>
                    <th>Материалы</th>
                    <th>Автор</th>
                    <th>Алиас</th>
                    <th>id</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(url( '/admin/' . $page->alias . '/edit', [$tag->id])); ?>"><?php echo e($tag->name); ?></a></td>
                        <td><?php echo e(count($tag->posts)); ?></td>
                        <td>
                            <?php echo e($tag->author->name); ?>

                        </td>
                        <td><?php echo e($tag->alias); ?></td>
                        <th scope="row"><?php echo e($tag->id); ?></th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>