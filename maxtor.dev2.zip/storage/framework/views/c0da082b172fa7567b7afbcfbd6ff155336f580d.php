<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('dashboard.components', ['alias' => $page->alias, 'method' => 'createMenuItem'])); ?>" class="btn btn-outline-info">
        Добавить пункт меню
    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mxtcore::layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>